import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib
from pathlib import Path
from math import radians, sin, cos, sqrt, atan2

# ---------------------------------------------------------
# AI Typhoon Track Prediction - Educational demonstration
# Required files:
#   app.py
#   requirements.txt
#   typhoon_data.csv
#   typhoon_rf_model.pkl
# ---------------------------------------------------------

st.set_page_config(
    page_title="AI 태풍 이동 경로 예측 시스템",
    page_icon="🌀",
    layout="wide"
)

DATA_PATH = Path(__file__).parent / "typhoon_data.csv"
MODEL_PATH = Path(__file__).parent / "typhoon_rf_model.pkl"

FEATURES = [
    "PREV_LAT", "PREV_LON", "LAT", "LON", "TIME_GAP", "NEXT_GAP"
]


def normalize_longitude(series):
    """Convert longitude to the -180..180 range."""
    return ((series.astype(float) + 180) % 360) - 180


def haversine_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in kilometers."""
    earth_radius_km = 6371.0
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    return 2 * earth_radius_km * atan2(sqrt(a), sqrt(1 - a))


@st.cache_data
def load_data(path_string):
    df = pd.read_csv(path_string, low_memory=False)

    required = ["SID", "NAME", "SEASON", "ISO_TIME", "LAT", "LON"]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(
            "CSV 파일에 필요한 열이 없습니다: " + ", ".join(missing)
        )

    df["SID"] = df["SID"].astype(str)
    df["NAME"] = df["NAME"].fillna("이름 미상").astype(str)
    df["SEASON"] = pd.to_numeric(df["SEASON"], errors="coerce")
    df["ISO_TIME"] = pd.to_datetime(df["ISO_TIME"], errors="coerce")
    df["LAT"] = pd.to_numeric(df["LAT"], errors="coerce")
    df["LON"] = pd.to_numeric(df["LON"], errors="coerce")

    df = df.dropna(subset=["SID", "ISO_TIME", "LAT", "LON", "SEASON"]).copy()
    df = df[(df["LAT"].between(-90, 90)) & (df["LON"].between(0, 360))].copy()
    df["LON"] = normalize_longitude(df["LON"])
    df["SEASON"] = df["SEASON"].astype(int)
    df = df.sort_values(["SID", "ISO_TIME"]).reset_index(drop=True)

    for col in ["WMO_WIND", "WMO_PRES"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    return df


@st.cache_resource
def load_model(path_string):
    return joblib.load(path_string)


def storm_label(row):
    return f'{int(row["SEASON"])}년 | {row["NAME"]} | {row["SID"]}'


def make_forecast(model, storm_df, forecast_hours):
    """Predict the next position using both RF and a linear-motion baseline."""
    storm_df = storm_df.sort_values("ISO_TIME").drop_duplicates("ISO_TIME")
    if len(storm_df) < 2:
        raise ValueError("예측하려면 해당 태풍의 관측 기록이 최소 2개 필요합니다.")

    previous = storm_df.iloc[-2]
    current = storm_df.iloc[-1]

    time_gap = (current["ISO_TIME"] - previous["ISO_TIME"]).total_seconds() / 3600
    if not np.isfinite(time_gap) or time_gap <= 0:
        raise ValueError("최근 두 관측 시각의 간격을 계산할 수 없습니다.")

    # Baseline: continue the latest observed movement at a constant speed.
    lat_change = current["LAT"] - previous["LAT"]
    lon_change = ((current["LON"] - previous["LON"] + 180) % 360) - 180

    baseline_lat = current["LAT"] + (lat_change / time_gap) * forecast_hours
    baseline_lon = current["LON"] + (lon_change / time_gap) * forecast_hours
    baseline_lon = ((baseline_lon + 180) % 360) - 180

    # The model was trained with these six input features.
    input_df = pd.DataFrame([{
        "PREV_LAT": float(previous["LAT"]),
        "PREV_LON": float(previous["LON"]),
        "LAT": float(current["LAT"]),
        "LON": float(current["LON"]),
        "TIME_GAP": float(time_gap),
        "NEXT_GAP": float(forecast_hours)
    }], columns=FEATURES)

    ml_prediction = model.predict(input_df)[0]
    ml_lat = float(ml_prediction[0])
    ml_lon = float(((float(ml_prediction[1]) + 180) % 360) - 180)

    return {
        "last_time": current["ISO_TIME"],
        "time_gap": time_gap,
        "previous": previous,
        "current": current,
        "baseline_lat": float(np.clip(baseline_lat, -90, 90)),
        "baseline_lon": baseline_lon,
        "ml_lat": float(np.clip(ml_lat, -90, 90)),
        "ml_lon": ml_lon
    }


st.title("🌀 AI 태풍 이동 경로 예측 시스템")
st.caption("과거 태풍 관측 데이터를 분석하고 머신러닝으로 다음 위치를 추정하는 교육용 프로젝트")

st.info(
    "주의: 이 웹사이트는 과거 데이터를 이용한 학습·탐구용 예측 모델입니다. "
    "공식 기상 예보가 아니며 실제 안전 판단이나 대피 결정에 사용하면 안 됩니다."
)

# Check required project files.
missing_files = [str(p.name) for p in [DATA_PATH, MODEL_PATH] if not p.exists()]
if missing_files:
    st.error(
        "필요한 파일을 찾을 수 없습니다: " + ", ".join(missing_files) +
        "\n\nGitHub 저장소의 app.py와 같은 폴더(최상위)에 두 파일을 업로드해 주세요."
    )
    st.stop()

try:
    data = load_data(str(DATA_PATH))
    model = load_model(str(MODEL_PATH))
except Exception as exc:
    st.error(f"데이터 또는 모델을 불러오는 중 오류가 발생했습니다: {exc}")
    st.stop()

if not hasattr(model, "predict"):
    st.error("저장된 모델에 predict 기능이 없습니다. Colab에서 학습 모델을 다시 저장해 주세요.")
    st.stop()

# Verify the feature schema where available.
if hasattr(model, "feature_names_in_"):
    saved_features = list(model.feature_names_in_)
    if saved_features != FEATURES:
        st.error(
            "저장된 모델의 입력 열 구성이 웹사이트 코드와 다릅니다.\n\n"
            f"모델 입력 열: {saved_features}\n웹사이트 입력 열: {FEATURES}\n\n"
            "Colab에서 모델 학습에 사용한 열 이름과 순서를 확인해야 합니다."
        )
        st.stop()

# Sidebar selection.
st.sidebar.header("태풍 선택")
storm_summary = (
    data.groupby(["SID", "SEASON", "NAME"], as_index=False)
    .agg(records=("ISO_TIME", "count"), first_time=("ISO_TIME", "min"), last_time=("ISO_TIME", "max"))
)
storm_summary = storm_summary.sort_values(["SEASON", "NAME"], ascending=[False, True])
storm_summary["label"] = storm_summary.apply(storm_label, axis=1)

selected_label = st.sidebar.selectbox(
    "분석할 태풍을 선택하세요",
    storm_summary["label"].tolist()
)
selected_row = storm_summary.loc[storm_summary["label"] == selected_label].iloc[0]
selected_sid = selected_row["SID"]
storm = data[data["SID"] == selected_sid].sort_values("ISO_TIME").copy()

forecast_hours = st.sidebar.select_slider(
    "예측 시간 간격",
    options=[6, 12, 18, 24],
    value=6,
    help="마지막 관측 시각으로부터 몇 시간 뒤의 위치를 추정할지 선택합니다."
)

# Top metrics.
m1, m2, m3 = st.columns(3)
m1.metric("관측 기록 수", f"{len(storm):,}개")
m2.metric("태풍 발생 연도", f'{int(selected_row["SEASON"])}년')
m3.metric("관측 기간", f'{storm["ISO_TIME"].min():%Y-%m-%d} ~ {storm["ISO_TIME"].max():%Y-%m-%d}')

st.subheader("1. 과거 태풍 이동 경로")
fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(storm["LON"], storm["LAT"], marker="o", markersize=2.5, linewidth=1.5, label="관측 경로")
ax.scatter(storm["LON"].iloc[0], storm["LAT"].iloc[0], marker="o", s=70, label="시작 위치")
ax.scatter(storm["LON"].iloc[-1], storm["LAT"].iloc[-1], marker="X", s=90, label="마지막 관측 위치")
ax.set_xlabel("경도 (°)")
ax.set_ylabel("위도 (°)")
ax.set_title(f'{selected_row["NAME"]} ({int(selected_row["SEASON"])}) 이동 경로')
ax.grid(True, alpha=0.3)
ax.legend()
st.pyplot(fig)
plt.close(fig)

# Wind and pressure analysis.
left, right = st.columns(2)

with left:
    st.subheader("2. 풍속 변화")
    if "WMO_WIND" in storm.columns and storm["WMO_WIND"].notna().any():
        wind = storm.dropna(subset=["WMO_WIND"])
        fig_w, ax_w = plt.subplots(figsize=(7, 3.5))
        ax_w.plot(wind["ISO_TIME"], wind["WMO_WIND"], marker=".", linewidth=1)
        ax_w.set_xlabel("관측 시각")
        ax_w.set_ylabel("풍속 (knot)")
        ax_w.grid(True, alpha=0.3)
        fig_w.autofmt_xdate()
        st.pyplot(fig_w)
        plt.close(fig_w)
        st.write(f'최대 관측 풍속: **{wind["WMO_WIND"].max():.1f} knot**')
    else:
        st.write("이 태풍의 풍속 자료가 없습니다.")

with right:
    st.subheader("3. 기압 변화")
    if "WMO_PRES" in storm.columns and storm["WMO_PRES"].notna().any():
        pressure = storm.dropna(subset=["WMO_PRES"])
        fig_p, ax_p = plt.subplots(figsize=(7, 3.5))
        ax_p.plot(pressure["ISO_TIME"], pressure["WMO_PRES"], marker=".", linewidth=1)
        ax_p.set_xlabel("관측 시각")
        ax_p.set_ylabel("기압 (hPa)")
        ax_p.grid(True, alpha=0.3)
        fig_p.autofmt_xdate()
        st.pyplot(fig_p)
        plt.close(fig_p)
        st.write(f'최저 관측 기압: **{pressure["WMO_PRES"].min():.1f} hPa**')
    else:
        st.write("이 태풍의 기압 자료가 없습니다.")

st.divider()
st.subheader("4. AI 다음 위치 예측")

if st.button("AI 예측 실행", type="primary", use_container_width=True):
    try:
        result = make_forecast(model, storm, forecast_hours)
        future_time = result["last_time"] + pd.Timedelta(hours=forecast_hours)

        st.success(f"예측 계산 완료 · 기준 시각: {result['last_time']:%Y-%m-%d %H:%M} UTC")
        a, b = st.columns(2)
        with a:
            st.markdown("**기존 방식(최근 이동 속도 유지)**")
            st.metric("예측 위도", f'{result["baseline_lat"]:.2f}°')
            st.metric("예측 경도", f'{result["baseline_lon"]:.2f}°')
        with b:
            st.markdown("**랜덤 포레스트 AI 모델**")
            st.metric("예측 위도", f'{result["ml_lat"]:.2f}°')
            st.metric("예측 경도", f'{result["ml_lon"]:.2f}°')

        st.write(f"예측 대상 시각: **{future_time:%Y-%m-%d %H:%M} UTC**")

        fig_f, ax_f = plt.subplots(figsize=(10, 5))
        ax_f.plot(storm["LON"], storm["LAT"], marker=".", markersize=3, label="과거 관측 경로")
        ax_f.scatter(result["current"]["LON"], result["current"]["LAT"], s=85, marker="X", label="마지막 관측 위치")
        ax_f.scatter(result["baseline_lon"], result["baseline_lat"], s=90, marker="^", label="기존 방식 예측")
        ax_f.scatter(result["ml_lon"], result["ml_lat"], s=90, marker="*", label="AI 예측")
        ax_f.plot(
            [result["current"]["LON"], result["baseline_lon"]],
            [result["current"]["LAT"], result["baseline_lat"]],
            linestyle="--", alpha=0.7
        )
        ax_f.plot(
            [result["current"]["LON"], result["ml_lon"]],
            [result["current"]["LAT"], result["ml_lat"]],
            linestyle=":", alpha=0.9
        )
        ax_f.set_xlabel("경도 (°)")
        ax_f.set_ylabel("위도 (°)")
        ax_f.set_title("마지막 관측 위치와 다음 위치 예측")
        ax_f.grid(True, alpha=0.3)
        ax_f.legend()
        st.pyplot(fig_f)
        plt.close(fig_f)

        st.caption(
            "두 예측값은 선택한 시간 간격 뒤의 추정 좌표입니다. "
            "미래의 실제 관측값이 없으므로 이 화면만으로 예측 정확도를 판단할 수 없습니다."
        )
    except Exception as exc:
        st.error(f"예측 중 오류가 발생했습니다: {exc}")

st.divider()
st.subheader("5. 데이터 미리보기")
st.dataframe(
    storm[["ISO_TIME", "NAME", "LAT", "LON"] +
          [c for c in ["WMO_WIND", "WMO_PRES"] if c in storm.columns]].tail(20),
    use_container_width=True,
    hide_index=True
)

st.caption("데이터 출처: NOAA IBTrACS. 본 프로젝트는 교육·탐구 목적으로 제작되었습니다.")
