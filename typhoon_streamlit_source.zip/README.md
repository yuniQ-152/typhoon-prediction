# AI 태풍 이동 경로 예측 시스템

## GitHub 저장소에 필요한 파일
- `app.py`
- `requirements.txt`
- `typhoon_data.csv` (Google Colab에서 저장한 태풍 데이터)
- `typhoon_rf_model.pkl` (Google Colab에서 학습한 RandomForestRegressor 모델)

## Streamlit Community Cloud 배포
- Repository: `yuniQ-152/typhoon-prediction`
- Branch: `main`
- Main file path: `app.py`

## 주의
이 앱은 과거 태풍 데이터를 이용한 교육용 예측 시연입니다.
공식 기상 예보나 실제 안전 판단에 사용하지 마세요.
